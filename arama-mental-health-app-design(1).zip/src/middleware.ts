import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

export function middleware(request: NextRequest) {
  const isAuthPage =
    request.nextUrl.pathname.startsWith("/login") ||
    request.nextUrl.pathname.startsWith("/signup");
  const isProtected = [
    "/dashboard",
    "/chat",
    "/exercises",
    "/meditation",
    "/reports",
    "/session-management",
    "/billing",
    "/profile",
    "/settings",
  ].some((path) => request.nextUrl.pathname.startsWith(path));

  const hasCookie = request.cookies.has("arama-user");

  if (isProtected && !hasCookie) {
    return NextResponse.redirect(new URL("/login", request.url));
  }

  if (isAuthPage && hasCookie) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!api|_next/static|_next/image|images|audio|favicon.ico|icon.svg).*)"],
};
