"use client";

import { useState, useEffect, useRef, useCallback } from "react";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, KeyRound, Lock, Phone, ShieldCheck } from "lucide-react";

type Step = "phone" | "otp" | "password" | "set-password";

const inputBase =
  "w-full rounded-2xl border bg-canvas/60 py-3.5 ps-11 pe-4 text-sm text-ink outline-none transition-all duration-300 placeholder:text-faint focus:border-brand focus:bg-card focus:shadow-[0_0_0_4px_color-mix(in_srgb,var(--brand)_14%,transparent))]";

function Field({
  id,
  label,
  icon: Icon,
  error,
  children,
}: {
  id: string;
  label: string;
  icon: typeof Phone;
  error?: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <label htmlFor={id} className="mb-2 block text-sm font-bold text-ink">
        {label}
      </label>
      <div className="relative">
        <Icon
          aria-hidden
          className={`pointer-events-none absolute start-4 top-1/2 size-4.5 -translate-y-1/2 transition-colors ${
            error ? "text-danger" : "text-faint"
          }`}
        />
        {children}
      </div>
      {error && (
        <p id={`${id}-error`} role="alert" className="animate-rise mt-2 flex items-center gap-1.5 text-xs font-semibold text-danger">
          <span aria-hidden className="size-1 rounded-full bg-danger" />
          {error}
        </p>
      )}
    </div>
  );
}

export function AuthForm() {
  const router = useRouter();
  const [step, setStep] = useState<Step>("phone");
  const [phone, setPhone] = useState("");
  const [hasPassword, setHasPassword] = useState(false);
  const [otpCode, setOtpCode] = useState(["", "", "", "", ""]);
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [showNewPass, setShowNewPass] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");
  const [isFirstLogin, setIsFirstLogin] = useState(false);
  const [countdown, setCountdown] = useState(0);
  const otpRefs = useRef<(HTMLInputElement | null)[]>([]);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // ── Countdown timer for OTP resend ──
  useEffect(() => {
    if (countdown <= 0) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }
    timerRef.current = setInterval(() => setCountdown((c) => c - 1), 1000);
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [countdown]);

  const countdownDisplay = useCallback(() => {
    const m = Math.floor(countdown / 60);
    const s = countdown % 60;
    return `${m}:${s.toString().padStart(2, "0")}`;
  }, [countdown]);

  const formattedCountdown = countdown > 0 ? countdownDisplay() : "";

  // ── Phone submission ──
  const requestOtp = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setError("");

    if (!/^09\d{9}$/.test(phone)) {
      setError("شماره موبایل معتبر نیست. فرمت صحیح: ۰۹۱۲۳۴۵۶۷۸۹");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/otp/request", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ phone }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string; hasPassword?: boolean };
      if (!res.ok) throw new Error(data.error || "ارسال کد انجام نشد.");

      setHasPassword(!!data.hasPassword);
      setStep("otp");
      setCountdown(120); // 2 minutes
      setOtpCode(["", "", "", "", ""]);
      setTimeout(() => otpRefs.current[0]?.focus(), 100);
    } catch (err) {
      setError(err instanceof Error ? err.message : "ارسال کد انجام نشد.");
    } finally {
      setSubmitting(false);
    }
  };

  // ── OTP digit input handler ──
  const handleOtpDigit = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;
    const next = [...otpCode];
    next[index] = value;
    setOtpCode(next);

    if (value && index < 4) {
      otpRefs.current[index + 1]?.focus();
    }

    // Auto-submit when all 5 digits are filled
    if (next.every((d) => d !== "") && value) {
      void verifyOtp(next.join(""));
    }
  };

  const handleOtpKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otpCode[index] && index > 0) {
      otpRefs.current[index - 1]?.focus();
    }
  };

  // ── OTP verification ──
  const verifyOtp = async (code?: string) => {
    const codeStr = code || otpCode.join("");
    setError("");

    if (codeStr.length !== 5) {
      setError("کد تأیید باید ۵ رقم باشد.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/otp/verify", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ phone, code: codeStr }),
      });
      const data = (await res.json().catch(() => ({}))) as {
        error?: string;
        isFirstLogin?: boolean;
        hasPassword?: boolean;
      };
      if (!res.ok) throw new Error(data.error || "تأیید کد انجام نشد.");

      setIsFirstLogin(!!data.isFirstLogin);

      if (data.isFirstLogin && !data.hasPassword) {
        setStep("set-password");
      } else {
        router.push("/dashboard");
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "تأیید کد انجام نشد.");
      setOtpCode(["", "", "", "", ""]);
      setTimeout(() => otpRefs.current[0]?.focus(), 100);
    } finally {
      setSubmitting(false);
    }
  };

  // ── Password login ──
  const loginWithPassword = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setError("");

    if (password.length < 8) {
      setError("رمز عبور باید دست‌کم ۸ نویسه باشد.");
      return;
    }

    setSubmitting(true);
    try {
      const res = await fetch("/api/auth/password", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ phone, password }),
      });
      const data = (await res.json().catch(() => ({}))) as { error?: string };
      if (!res.ok) throw new Error(data.error || "ورود انجام نشد.");
      router.push("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "ورود انجام نشد.");
    } finally {
      setSubmitting(false);
    }
  };

  // ── Set optional password (first-time login) ──
  const setOptionalPassword = async (e?: React.FormEvent) => {
    e?.preventDefault();
    setError("");

    if (newPassword && newPassword.length < 8) {
      setError("رمز عبور باید دست‌کم ۸ نویسه باشد.");
      return;
    }

    setSubmitting(true);
    try {
      if (newPassword) {
        const res = await fetch("/api/profile", {
          method: "PUT",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ name: "", password: newPassword }),
        });
        if (!res.ok) throw new Error("ذخیره رمز عبور انجام نشد.");
      }
      router.push("/dashboard");
    } catch (err) {
      setError(err instanceof Error ? err.message : "ذخیره تنظیمات انجام نشد.");
    } finally {
      setSubmitting(false);
    }
  };

  const submitLabel = () => {
    if (submitting) return "در حال تأیید…";
    if (step === "phone") return "دریافت کد ورود";
    if (step === "otp") return "تأیید کد";
    if (step === "password") return "ورود با رمز عبور";
    if (step === "set-password") return newPassword ? "ذخیره و ادامه" : "ورود به آراما";
    return "ادامه";
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (step === "phone") void requestOtp();
    else if (step === "otp") void verifyOtp();
    else if (step === "password") void loginWithPassword();
    else if (step === "set-password") void setOptionalPassword();
  };

  return (
    <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-5">
      {/* ── STEP: Phone number entry ── */}
      {step === "phone" && (
        <Field id="auth-phone" label="شماره موبایل" icon={Phone} error={error || undefined}>
          <input
            id="auth-phone"
            type="tel"
            dir="ltr"
            inputMode="numeric"
            autoComplete="tel"
            placeholder="۰۹۱۲۳۴۵۶۷۸۹"
            value={phone}
            onChange={(e) => setPhone(e.target.value.replace(/[^\d]/g, "").slice(0, 11))}
            className={`${inputBase} text-left tracking-widest`}
            autoFocus
          />
        </Field>
      )}

      {/* ── STEP: OTP entry ── */}
      {step === "otp" && (
        <>
          <div className="text-center">
            <p className="text-sm font-bold text-ink">کد تأیید را وارد کن</p>
            <p className="mt-2 text-xs text-soft">
              کد ۵ رقمی ارسال‌شده به <span dir="ltr" className="font-bold text-ink">{phone}</span> را بنویس
            </p>
          </div>

          <div className="flex justify-center gap-3" dir="ltr">
            {otpCode.map((digit, i) => (
              <input
                key={i}
                ref={(el) => { otpRefs.current[i] = el; }}
                type="text"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleOtpDigit(i, e.target.value)}
                onKeyDown={(e) => handleOtpKeyDown(i, e)}
                aria-label={`رقم ${i + 1}`}
                className="size-14 rounded-2xl border border-line bg-card text-center text-xl font-black text-ink outline-none transition-all focus:border-brand focus:shadow-[0_0_0_4px_color-mix(in_srgb,var(--brand)_14%,transparent)]"
                autoFocus={i === 0}
              />
            ))}
          </div>

          {countdown > 0 ? (
            <p className="text-center text-xs font-semibold text-faint">
              ارسال مجدد کد تا <span className="font-black text-brand-ink">{formattedCountdown}</span>
            </p>
          ) : (
            <button
              type="button"
              onClick={() => void requestOtp()}
              className="mx-auto text-xs font-bold text-brand-ink underline-offset-4 hover:underline"
            >
              ارسال مجدد کد
            </button>
          )}

          {hasPassword && (
            <button
              type="button"
              onClick={() => { setStep("password"); setError(""); }}
              className="mx-auto inline-flex items-center gap-2 text-xs font-bold text-clay"
            >
              <Lock className="size-3.5" />
              ورود با رمز عبور
            </button>
          )}

          <button
            type="button"
            onClick={() => { setStep("phone"); setError(""); setOtpCode(["", "", "", "", ""]); }}
            className="mx-auto text-xs font-medium text-faint hover:text-ink"
          >
            تغییر شماره موبایل
          </button>

          {error && (
            <div role="alert" className="animate-rise rounded-2xl border border-danger/25 bg-danger/5 px-4 py-3 text-xs font-semibold leading-6 text-danger">
              {error}
            </div>
          )}
        </>
      )}

      {/* ── STEP: Password login ── */}
      {step === "password" && (
        <>
          <Field id="auth-password" label="رمز عبور" icon={Lock} error={error || undefined}>
            <input
              id="auth-password"
              type={showPass ? "text" : "password"}
              autoComplete="current-password"
              placeholder="رمز عبورت را بنویس"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className={`${inputBase} pe-12`}
            />
            <button
              type="button"
              onClick={() => setShowPass((v) => !v)}
              aria-label={showPass ? "پنهان‌کردن رمز عبور" : "نمایش رمز عبور"}
              className="absolute end-3.5 top-1/2 -translate-y-1/2 rounded-full p-1 text-faint transition-colors hover:text-brand-ink"
            >
              {showPass ? <EyeOff className="size-4.5" /> : <Eye className="size-4.5" />}
            </button>
          </Field>

          <button
            type="button"
            onClick={() => { setStep("otp"); setError(""); setCountdown(0); }}
            className="inline-flex items-center gap-2 text-xs font-bold text-clay"
          >
            <KeyRound className="size-3.5" />
            دریافت کد ورود (بدون رمز عبور)
          </button>
        </>
      )}

      {/* ── STEP: Optional password setup (first-time) ── */}
      {step === "set-password" && (
        <>
          <div className="rounded-2xl border border-sand bg-sand-soft/60 p-5">
            <div className="flex items-center gap-2 text-sm font-extrabold text-clay">
              <ShieldCheck className="size-5" />
              برای ورود سریع‌تر دفعات بعد
            </div>
            <p className="mt-2 text-xs leading-6 text-soft">
              یک رمز عبور تعیین کن تا دفعات بعد بدون نیاز به پیامک وارد شوی. این مرحله اختیاری است.
            </p>
          </div>

          <div>
            <label htmlFor="new-password" className="mb-2 block text-sm font-bold text-ink">
              رمز عبور جدید (اختیاری)
            </label>
            <div className="relative">
              <Lock
                aria-hidden
                className="pointer-events-none absolute start-4 top-1/2 size-4.5 -translate-y-1/2 text-faint"
              />
              <input
                id="new-password"
                type={showNewPass ? "text" : "password"}
                autoComplete="new-password"
                placeholder="دست‌کم ۸ نویسه"
                value={newPassword}
                onChange={(e) => setNewPassword(e.target.value)}
                className={`${inputBase} pe-12`}
              />
              <button
                type="button"
                onClick={() => setShowNewPass((v) => !v)}
                aria-label={showNewPass ? "پنهان‌کردن رمز عبور" : "نمایش رمز عبور"}
                className="absolute end-3.5 top-1/2 -translate-y-1/2 rounded-full p-1 text-faint transition-colors hover:text-brand-ink"
              >
                {showNewPass ? <EyeOff className="size-4.5" /> : <Eye className="size-4.5" />}
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={() => void setOptionalPassword()}
            className="text-xs font-bold text-faint hover:text-ink"
          >
            رد کردن، فقط با کد ورود می‌کنم
          </button>

          {error && (
            <div role="alert" className="animate-rise rounded-2xl border border-danger/25 bg-danger/5 px-4 py-3 text-xs font-semibold leading-6 text-danger">
              {error}
            </div>
          )}
        </>
      )}

      {/* ── Global error for phone/password steps ── */}
      {(step === "phone" || step === "password") && error && (
        <div role="alert" className="animate-rise rounded-2xl border border-danger/25 bg-danger/5 px-4 py-3 text-xs font-semibold leading-6 text-danger">
          {error}
        </div>
      )}

      {/* ── Submit button ── */}
      {step !== "otp" && (
        <button
          type="submit"
          disabled={submitting}
          className="group mt-1 inline-flex items-center justify-center gap-2.5 rounded-full bg-brand-deep px-6 py-4 text-sm font-black text-onbrand shadow-[var(--shadow-brand)] transition-all duration-500 hover:-translate-y-0.5 hover:brightness-110 disabled:translate-y-0 disabled:opacity-85"
        >
          {submitting ? (
            <>
              <span className="animate-breathe size-3 rounded-full bg-onbrand" aria-hidden />
              در حال تأیید…
            </>
          ) : (
            submitLabel()
          )}
        </button>
      )}

      <p className="flex items-center justify-center gap-2 text-[11px] font-medium text-faint">
        <span aria-hidden className="size-1.5 rounded-full bg-brand" />
        اطلاعات تو نزد ما امانت است
      </p>
    </form>
  );
}
