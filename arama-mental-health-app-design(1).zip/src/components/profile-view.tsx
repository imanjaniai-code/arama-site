"use client";

import { useEffect, useState, type FormEvent } from "react";
import { Check, RefreshCw, UserRound, WifiOff } from "lucide-react";

type Profile = {
  userId: string;
  name: string;
  phone: string;
  email: string | null;
  timezone: string;
  remindersEnabled: boolean;
  avatarUrl: string | null;
};

export function ProfileView() {
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [saveError, setSaveError] = useState("");

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/profile", { cache: "no-store" });
      const data = (await response.json()) as { profile?: Profile; error?: string };
      if (!response.ok) throw new Error(data.error || "بارگذاری نشد.");
      setProfile(data.profile ?? null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "پروفایل بارگذاری نشد.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const save = async (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (!profile) return;
    const formData = new FormData(e.currentTarget);
    const name = String(formData.get("name") ?? "").trim();
    const timezone = String(formData.get("timezone") ?? "Asia/Tehran");
    const password = String(formData.get("password") ?? "");
    const avatarUrl = String(formData.get("avatarUrl") ?? "");

    if (name.length < 2) {
      setSaveError("نامت را کامل بنویس.");
      return;
    }

    setSaving(true);
    setSaveError("");
    setSaved(false);
    try {
      const payload: Record<string, any> = { name, timezone, remindersEnabled: profile.remindersEnabled };
      if (password) payload.password = password;
      if (avatarUrl) payload.avatarUrl = avatarUrl;
      const response = await fetch("/api/profile", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = (await response.json()) as { profile?: Profile; error?: string };
      if (!response.ok) throw new Error(data.error || "ذخیره نشد.");
      setProfile(data.profile ?? profile);
      setSaved(true);
      setTimeout(() => setSaved(false), 3000);
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : "ذخیره انجام نشد.");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="card-soft rounded-[1.75rem] p-7">
        <div className="calm-skeleton mx-auto size-20 rounded-full" />
        <div className="calm-skeleton mx-auto mt-5 h-5 w-40 rounded-full" />
        <div className="calm-skeleton mx-auto mt-3 h-4 w-56 rounded-full" />
        <div className="calm-skeleton mt-8 h-12 w-full rounded-2xl" />
        <div className="calm-skeleton mt-4 h-12 w-full rounded-2xl" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="card-soft rounded-[1.75rem] p-12 text-center">
        <WifiOff className="mx-auto size-8 text-danger" />
        <p className="mt-4 text-sm font-bold text-ink">{error}</p>
        <button
          type="button"
          onClick={() => void load()}
          className="mt-5 inline-flex items-center gap-2 rounded-full bg-brand-deep px-5 py-2.5 text-xs font-bold text-onbrand"
        >
          <RefreshCw className="size-3.5" />
          تلاش دوباره
        </button>
      </div>
    );
  }

  if (!profile) return null;

  const initial = profile.name.trim().charAt(0) || "آ";

  return (
    <div className="mx-auto max-w-2xl">
      <div className="card-soft rounded-[1.75rem] p-7">
        {/* avatar */}
        <div className="flex flex-col items-center">
          {profile.avatarUrl ? (
            <img src={profile.avatarUrl} alt="" className="size-20 rounded-full object-cover shadow-[var(--shadow-soft)]" />
          ) : (
            <span className="grid size-20 place-items-center rounded-full bg-gradient-to-br from-brand-glow to-brand-deep text-3xl font-black text-white">
              {initial}
            </span>
          )}
          <h2 className="mt-4 text-xl font-black text-ink">{profile.name}</h2>
          <p className="mt-1 text-sm text-faint" dir="ltr">{profile.email}</p>
        </div>

        {/* form */}
        <form onSubmit={(e) => void save(e)} className="mt-8 space-y-5">
          <div>
            <label htmlFor="profile-name" className="mb-2 block text-sm font-bold text-ink">
              نام
            </label>
            <input
              id="profile-name"
              name="name"
              type="text"
              defaultValue={profile.name}
              className="w-full rounded-2xl border border-line bg-canvas/60 py-3.5 ps-4 pe-4 text-sm text-ink outline-none transition-all focus:border-brand focus:bg-card focus:shadow-[0_0_0_4px_color-mix(in_srgb,var(--brand)_14%,transparent)]"
            />
          </div>
          <div>
            <label className="mb-2 block text-sm font-bold text-ink">
              شماره موبایل
            </label>
            <p className="rounded-2xl border border-line bg-tint px-4 py-3.5 text-sm font-semibold text-ink" dir="ltr">
              {profile.phone}
            </p>
            <p className="mt-2 text-[11px] text-faint">شماره موبایل شناسهٔ اصلی حساب توست.</p>
          </div>
          <div>
            <label htmlFor="profile-timezone" className="mb-2 block text-sm font-bold text-ink">
              منطقهٔ زمانی
            </label>
            <select
              id="profile-timezone"
              name="timezone"
              defaultValue={profile.timezone}
              className="w-full rounded-2xl border border-line bg-canvas/60 py-3.5 ps-4 pe-4 text-sm text-ink outline-none transition-all focus:border-brand focus:bg-card"
            >
              <option value="Asia/Tehran">تهران (UTC+3:30)</option>
              <option value="Asia/Kabul">کابل (UTC+4:30)</option>
              <option value="Asia/Dubai">دبی (UTC+4)</option>
              <option value="Europe/Istanbul">استانبول (UTC+3)</option>
              <option value="Europe/London">لندن (UTC+0/+1)</option>
              <option value="America/Toronto">تورنتو (UTC-5/-4)</option>
              <option value="America/Los_Angeles">لس‌آنجلس (UTC-8/-7)</option>
            </select>
          </div>
          <div>
            <label htmlFor="profile-avatar" className="mb-2 block text-sm font-bold text-ink">آدرس تصویر پروفایل (اختیاری)</label>
            <input
              id="profile-avatar"
              name="avatarUrl"
              type="url"
              dir="ltr"
              placeholder="https://..."
              defaultValue={profile.avatarUrl ?? ""}
              className="w-full rounded-2xl border border-line bg-canvas/60 py-3.5 ps-4 pe-4 text-sm text-ink outline-none transition-all focus:border-brand focus:bg-card"
            />
          </div>
          <div>
            <label htmlFor="profile-password" className="mb-2 block text-sm font-bold text-ink">تغییر رمز عبور</label>
            <input
              id="profile-password"
              name="password"
              type="password"
              placeholder="در صورت عدم تمایل خالی بگذارید"
              className="w-full rounded-2xl border border-line bg-canvas/60 py-3.5 ps-4 pe-4 text-sm text-ink outline-none transition-all focus:border-brand focus:bg-card"
            />
          </div>

          {saveError && (
            <p role="alert" className="text-xs font-semibold text-danger">{saveError}</p>
          )}

          <button
            type="submit"
            disabled={saving}
            className="inline-flex items-center gap-2 rounded-full bg-brand-deep px-6 py-3.5 text-sm font-bold text-onbrand shadow-[var(--shadow-brand)] transition-all duration-500 hover:-translate-y-0.5 hover:brightness-110 disabled:translate-y-0 disabled:opacity-70"
          >
            {saving ? (
              <>
                <span className="animate-breathe size-3 rounded-full bg-onbrand" />
                در حال ذخیره…
              </>
            ) : saved ? (
              <>
                <Check className="size-4" />
                ذخیره شد
              </>
            ) : (
              "ذخیرهٔ تغییرات"
            )}
          </button>
        </form>
      </div>
    </div>
  );
}
