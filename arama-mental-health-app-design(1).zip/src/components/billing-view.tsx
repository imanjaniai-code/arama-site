"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Check, CreditCard, RefreshCw, Shield, Sparkles, WifiOff } from "lucide-react";

type Sub = {
  subscription: {
    id: string;
    status: string;
    amount: number;
    interval: string;
    startedAt: string;
    renewsAt: string;
  };
  plan: {
    id: string;
    name: string;
    price: number;
    unit: string;
    period: string;
    description: string;
    features: string[];
    featured: boolean;
  };
};

export function BillingView() {
  const [sub, setSub] = useState<Sub | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [canceling, setCanceling] = useState(false);
  const [cancelError, setCancelError] = useState("");

  const load = async () => {
    setLoading(true);
    setError("");
    try {
      const response = await fetch("/api/subscription", { cache: "no-store" });
      const data = (await response.json()) as { subscription?: Sub; error?: string };
      if (!response.ok) throw new Error(data.error || "بارگذاری نشد.");
      setSub(data.subscription ?? null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "اطلاعات اشتراک بارگذاری نشد.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void load();
  }, []);

  const cancel = async () => {
    if (!confirm("اشتراکت لغو می‌شود. تا پایان دورهٔ فعلی، همهٔ امکانات فعال می‌ماند. مطمئنی؟")) return;
    setCanceling(true);
    setCancelError("");
    try {
      const response = await fetch("/api/subscription", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ action: "cancel" }),
      });
      if (!response.ok) throw new Error("لغو اشتراک انجام نشد.");
      await load();
    } catch (err) {
      setCancelError(err instanceof Error ? err.message : "لغو اشتراک انجام نشد.");
    } finally {
      setCanceling(false);
    }
  };

  if (loading) {
    return (
      <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
        <div className="card-soft rounded-[1.75rem] p-7">
          <div className="calm-skeleton h-6 w-40 rounded-full" />
          <div className="calm-skeleton mt-5 h-16 w-full rounded-2xl" />
          <div className="calm-skeleton mt-5 h-4 w-60 rounded-full" />
          <div className="calm-skeleton mt-3 h-4 w-44 rounded-full" />
        </div>
        <div className="card-soft rounded-[1.75rem] p-7">
          <div className="calm-skeleton h-5 w-32 rounded-full" />
          <div className="calm-skeleton mt-6 h-32 w-full rounded-2xl" />
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="card-soft rounded-[1.75rem] p-12 text-center">
        <WifiOff className="mx-auto size-8 text-danger" />
        <p className="mt-4 text-sm font-bold text-ink">{error}</p>
        <button
          type="button"
          onClick={() => void load()}
          className="mt-5 inline-flex items-center gap-2 rounded-full bg-brand-deep px-5 py-2.5 text-xs font-bold text-onbrand"
        >
          <RefreshCw className="size-3.5" />
          تلاش دوباره
        </button>
      </div>
    );
  }

  if (!sub) {
    return (
      <div className="card-soft rounded-[1.75rem] p-12 text-center">
        <CreditCard className="mx-auto size-9 text-faint" />
        <p className="mt-4 text-base font-extrabold text-ink">هنوز اشتراکی فعال نداری</p>
        <p className="mt-2 text-sm leading-7 text-soft">
          با اشتراک آراما، به همهٔ مدیتیشن‌ها، تمرین‌ها و گفتگوی نامحدود دسترسی پیدا کن.
        </p>
        <Link
          href="/#pricing"
          className="mt-5 inline-flex rounded-full bg-brand-deep px-6 py-3 text-sm font-bold text-onbrand shadow-[var(--shadow-brand)]"
        >
          مشاهدهٔ تعرفه‌ها
        </Link>
      </div>
    );
  }

  const plan = sub.plan;
  const subscription = sub.subscription;
  const isActive = subscription.status === "active";
  const renewDate = new Date(subscription.renewsAt).toLocaleDateString("fa-IR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
  const startDate = new Date(subscription.startedAt).toLocaleDateString("fa-IR", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <div className="grid gap-6 lg:grid-cols-[1.2fr_0.8fr]">
      {/* plan details */}
      <div className="card-soft rounded-[1.75rem] p-7">
        <div className="flex items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid size-12 place-items-center rounded-2xl bg-brand-deep text-onbrand">
              <Sparkles className="size-5" />
            </span>
            <div>
              <h2 className="text-lg font-extrabold text-ink">{plan.name}</h2>
              <p className="text-xs font-medium text-faint">{plan.description}</p>
            </div>
          </div>
          <span
            className={`rounded-full px-3 py-1.5 text-[11px] font-black ${
              isActive
                ? "bg-tint-strong text-brand-ink"
                : "bg-sand-soft text-clay"
            }`}
          >
            {isActive ? "فعال" : "لغو‌شده"}
          </span>
        </div>

        <div className="mt-6 flex items-end gap-2">
          <span className="text-4xl font-black tracking-tight text-ink">
            {plan.price > 0 ? plan.price.toLocaleString("fa-IR") : "رایگان"}
          </span>
          {plan.price > 0 && (
            <span className="pb-1.5 text-xs font-semibold text-faint">{plan.unit}</span>
          )}
        </div>

        <div className="mt-6 flex flex-wrap gap-x-8 gap-y-2 border-t border-line pt-5 text-xs font-semibold text-soft">
          <span>شروع: {startDate}</span>
          <span>{isActive ? `تمدید خودکار: ${renewDate}` : `فعال تا: ${renewDate}`}</span>
        </div>

        <ul className="mt-6 flex flex-col gap-2.5">
          {plan.features.map((feature) => (
            <li key={feature} className="flex items-start gap-2.5 text-sm leading-6 text-soft">
              <span className="mt-0.5 grid size-5 shrink-0 place-items-center rounded-full bg-tint-strong text-brand-ink">
                <Check className="size-3" strokeWidth={3} />
              </span>
              {feature}
            </li>
          ))}
        </ul>

        {isActive && (
          <div className="mt-7 flex flex-wrap items-center gap-3 border-t border-line pt-6">
            <button
              type="button"
              onClick={async () => {
                setCanceling(true);
                setCancelError("");
                try {
                  const response = await fetch("/api/subscription", {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({ action: "upgrade", planId: plan.id === "pro" ? "plus" : "pro" }),
                  });
                  if (!response.ok) throw new Error("تغییر اشتراک انجام نشد.");
                  await load();
                } catch (err) {
                  setCancelError(err instanceof Error ? err.message : "تغییر اشتراک انجام نشد.");
                } finally {
                  setCanceling(false);
                }
              }}
              disabled={canceling}
              className="rounded-full bg-brand-deep px-5 py-3 text-sm font-bold text-onbrand shadow-[var(--shadow-brand)] transition-all duration-500 hover:-translate-y-0.5 hover:brightness-110 disabled:opacity-50"
            >
              ارتقا به {plan.id === "pro" ? "آرامش پلاس" : "حرفه‌ای"}
            </button>
            <button
              type="button"
              onClick={() => void cancel()}
              disabled={canceling}
              className="rounded-full border border-line px-5 py-3 text-sm font-bold text-soft transition-colors hover:border-danger/40 hover:text-danger disabled:opacity-50"
            >
              {canceling ? "در حال لغو…" : "لغو اشتراک"}
            </button>
          </div>
        )}
        {!isActive && (
          <div className="mt-7 border-t border-line pt-6">
            <button
              type="button"
              onClick={async () => {
                setCanceling(true);
                setCancelError("");
                try {
                  const response = await fetch("/api/subscription", {
                    method: "POST",
                    headers: { "content-type": "application/json" },
                    body: JSON.stringify({ action: "subscribe", planId: plan.id }),
                  });
                  if (!response.ok) throw new Error("فعال‌سازی انجام نشد.");
                  await load();
                } catch (err) {
                  setCancelError(err instanceof Error ? err.message : "فعال‌سازی انجام نشد.");
                } finally {
                  setCanceling(false);
                }
              }}
              disabled={canceling}
              className="rounded-full bg-brand-deep px-5 py-3 text-sm font-bold text-onbrand shadow-[var(--shadow-brand)] disabled:opacity-50"
            >
              فعال‌سازی دوباره
            </button>
          </div>
        )}
        {cancelError && (
          <p role="alert" className="mt-4 text-xs font-semibold text-danger">
            {cancelError}
          </p>
        )}
      </div>

      {/* safety & trust */}
      <div className="space-y-5">
        <div className="card-soft rounded-[1.75rem] p-7">
          <Shield className="size-7 text-brand" />
          <h3 className="mt-4 text-base font-extrabold text-ink">حریم مالی تو امن است</h3>
          <p className="mt-3 text-sm leading-7 text-soft">
            پرداخت از درگاه امن انجام می‌شود. اطلاعات کارت تو نزد آراما ذخیره نمی‌شود. هر زمان بخواهی
            اشتراکت لغو می‌شود — بدون سؤال و بدون فشار.
          </p>
        </div>
        <div className="card-soft rounded-[1.75rem] p-7">
          <h3 className="text-sm font-extrabold text-ink">۷ روز ضمانت بازگشت وجه</h3>
          <p className="mt-2 text-xs leading-6 text-soft">
            اگر در هفتهٔ اول احساس کردی آراما مناسبت نیست، تمام مبلغ برگردانده می‌شود.
          </p>
        </div>
      </div>
    </div>
  );
}
