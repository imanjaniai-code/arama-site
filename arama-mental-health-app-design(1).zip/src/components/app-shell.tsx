"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  AudioLines,
  BarChart3,
  BookOpen,
  CreditCard,
  LayoutDashboard,
  LifeBuoy,
  MessageCircleHeart,
  Settings,
  UserRound,
  Wind,
} from "lucide-react";
import { Logo } from "./logo";
import { ThemeToggle } from "./theme-toggle";

const nav = [
  { href: "/dashboard", label: "داشبورد", icon: LayoutDashboard },
  { href: "/chat", label: "گفتگو", icon: MessageCircleHeart },
  { href: "/exercises", label: "تمرین‌ها", icon: Wind },
  { href: "/meditation", label: "مدیتیشن", icon: AudioLines },
  { href: "/reports", label: "گزارش‌ها", icon: BarChart3 },
  { href: "/session-management", label: "تاریخچه", icon: BookOpen },
  { href: "/billing", label: "اشتراک", icon: CreditCard },
  { href: "/profile", label: "پروفایل", icon: UserRound },
  { href: "/settings", label: "تنظیمات", icon: Settings },
];

export function AppShell({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();

  return (
    <div className="flex min-h-dvh bg-canvas">
      {/* sidebar — first in flow → sits on the right in RTL */}
      <aside className="sticky top-0 hidden h-dvh w-72 shrink-0 flex-col gap-1.5 border-e border-line bg-card/70 p-5 backdrop-blur lg:flex">
        <div className="px-2 pb-5">
          <Logo size="sm" />
        </div>

        <nav aria-label="ناوبری اپلیکیشن" className="flex flex-1 flex-col gap-1.5">
          {nav.map((n) => {
            const active = pathname === n.href;
            return (
              <Link
                key={n.label}
                href={n.href}
                aria-current={active ? "page" : undefined}
                className={`group flex items-center gap-3 rounded-2xl px-4 py-3 text-sm font-semibold transition-all duration-300 ${
                  active ? "bg-tint-strong text-brand-ink" : "text-soft hover:bg-tint hover:text-ink"
                }`}
              >
                <n.icon className="size-5 transition-transform duration-300 group-hover:scale-110" strokeWidth={2} />
                {n.label}
              </Link>
            );
          })}
        </nav>

        <div className="rounded-3xl border border-sand bg-sand-soft/70 p-4">
          <p className="flex items-center gap-2 text-xs font-extrabold text-clay">
            <LifeBuoy className="size-4" />
            نیاز فوری به کمک؟
          </p>
          <p className="mt-2 text-[11px] leading-5 text-soft">
            اگر در بحران روانی هستی، با اورژانس اجتماعی <strong className="text-ink">۱۲۳</strong> تماس بگیر.
          </p>
        </div>

        <div className="mt-2 flex items-center justify-between gap-2 rounded-3xl border border-line bg-card p-3">
          <div className="flex items-center gap-2.5">
            <span className="grid size-10 place-items-center rounded-full bg-gradient-to-br from-brand-glow to-brand-deep text-sm font-black text-white">
              س
            </span>
            <div>
              <p className="text-xs font-bold text-ink">سارا محمدی</p>
              <p className="text-[10px] font-medium text-faint">آرامش پلاس</p>
            </div>
          </div>
          <ThemeToggle />
        </div>
      </aside>

      {/* content */}
      <div className="flex min-w-0 flex-1 flex-col pb-24 lg:pb-0">{children}</div>

      {/* mobile bottom nav */}
      <nav
        aria-label="ناوبری موبایل"
        className="fixed inset-x-4 bottom-4 z-40 flex items-center justify-around rounded-full border border-line bg-card/90 px-2 py-2 shadow-[var(--shadow-lift)] backdrop-blur-xl lg:hidden"
      >
        {nav.slice(0, 4).map((n) => {
          const active = pathname === n.href;
          return (
            <Link
              key={n.label}
              href={n.href}
              aria-current={active ? "page" : undefined}
              aria-label={n.label}
              className={`flex flex-col items-center gap-1 rounded-full px-4 py-2 text-[10px] font-bold transition-colors ${
                active ? "bg-tint-strong text-brand-ink" : "text-faint hover:text-ink"
              }`}
            >
              <n.icon className="size-5" />
              {n.label}
            </Link>
          );
        })}
      </nav>
    </div>
  );
}
