import { cookies } from "next/headers";
import { NextResponse } from "next/server";

export async function getSessionUserId() {
  const cookieStore = await cookies();
  const userId = cookieStore.get("arama-user")?.value;
  return userId || null;
}

export function unauthorized() {
  return NextResponse.json({ error: "شما وارد حساب نشده‌اید." }, { status: 401 });
}
