import { and, desc, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { conversations, messages } from "@/db/schema";
import { getSessionUserId, unauthorized } from "@/lib/session";

export async function GET() {
  try {
    const userId = await getSessionUserId();
    if (!userId) return unauthorized();

    const rows = await db
      .select()
      .from(conversations)
      .where(eq(conversations.userId, userId))
      .orderBy(desc(conversations.updatedAt));
      
    const result = await Promise.all(
      rows.map(async (conversation) => {
        const [last] = await db
          .select({ content: messages.content, createdAt: messages.createdAt })
          .from(messages)
          .where(eq(messages.conversationId, conversation.id))
          .orderBy(desc(messages.createdAt))
          .limit(1);
        return { ...conversation, lastMessage: last?.content ?? null, lastMessageAt: last?.createdAt ?? null };
      }),
    );
    return NextResponse.json({ conversations: result });
  } catch {
    return NextResponse.json({ error: "تاریخچهٔ گفتگوها فعلاً در دسترس نیست." }, { status: 503 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const userId = await getSessionUserId();
    if (!userId) return unauthorized();

    const { id } = (await request.json()) as { id?: string };
    if (!id) return NextResponse.json({ error: "شناسهٔ گفتگو لازم است." }, { status: 400 });
    
    // Authorization check is done by verifying conversation belongs to userId
    await db.delete(conversations).where(and(eq(conversations.id, id), eq(conversations.userId, userId)));
    // Messages cascade on delete
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ error: "حذف گفتگو انجام نشد." }, { status: 500 });
  }
}
