import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { and, desc, eq, gt } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { otpCodes, profiles } from "@/db/schema";

const IRAN_PHONE = /^09\d{9}$/;

/** Hash a 5-digit OTP with a random salt — never stored or logged in plaintext. */
function hashOtp(code: string): string {
  const salt = randomBytes(16).toString("hex");
  const buf = scryptSync(code, salt, 64);
  return `${salt}:${buf.toString("hex")}`;
}

function verifyOtp(code: string, stored: string): boolean {
  if (!stored || !stored.includes(":")) return false;
  const [salt, key] = stored.split(":");
  const keyBuf = Buffer.from(key, "hex");
  const derivedKey = scryptSync(code, salt, 64);
  return keyBuf.length === derivedKey.length && timingSafeEqual(keyBuf, derivedKey);
}

/** Send SMS via MeliPayamak pattern-based API. */
async function sendSms(phone: string, code: string): Promise<boolean> {
  const username = process.env.MELIPAYAMAK_USERNAME;
  const password = process.env.MELIPAYAMAK_PASSWORD;
  const patternCode = process.env.MELIPAYAMAK_PATTERN_CODE;

  if (!username || !password || !patternCode) {
    // Dev mode: skip SMS, log to console (never log in production)
    if (process.env.NODE_ENV !== "production") {
      console.log(`[DEV OTP] ${phone} → ${code}`);
    }
    return true; // allow flow to continue in dev
  }

  try {
    const res = await fetch(
      "https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          username,
          password,
          text: code,
          to: phone,
          bodyId: Number(patternCode),
        }),
      },
    );
    const data = (await res.json()) as { IsSuccessful?: boolean };
    return data.IsSuccessful === true;
  } catch {
    return false;
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as { phone?: string };
    const phone = body.phone?.trim();

    if (!phone || !IRAN_PHONE.test(phone)) {
      return NextResponse.json(
        { error: "شماره موبایل معتبر نیست. فرمت صحیح: ۰۹۱۲۳۴۵۶۷۸۹" },
        { status: 400 },
      );
    }

    // ── Rate-limit: max 3 OTP requests per phone per 10 minutes ──
    const tenMinsAgo = new Date(Date.now() - 10 * 60 * 1000);
    const recent = await db
      .select()
      .from(otpCodes)
      .where(and(eq(otpCodes.phone, phone), gt(otpCodes.createdAt, tenMinsAgo)))
      .orderBy(desc(otpCodes.createdAt));

    if (recent.length >= 3) {
      return NextResponse.json(
        { error: "تعداد درخواست کد تأیید بیش از حد مجاز است. لطفاً ۱۰ دقیقه دیگر تلاش کنید." },
        { status: 429 },
      );
    }

    // ── Generate 5-digit code ──
    const code = String(Math.floor(10000 + Math.random() * 90000));
    const codeHash = hashOtp(code);
    const expiresAt = new Date(Date.now() + 2 * 60 * 1000); // 2 minutes

    await db.insert(otpCodes).values({ phone, codeHash, expiresAt });

    const smsOk = await sendSms(phone, code);
    if (!smsOk) {
      return NextResponse.json(
        { error: "ارسال پیامک انجام نشد. لطفاً دوباره تلاش کنید." },
        { status: 503 },
      );
    }

    // Check if user has a password set — so the UI can offer the password path
    const [existingUser] = await db
      .select({ passwordHash: profiles.passwordHash })
      .from(profiles)
      .where(eq(profiles.phone, phone))
      .limit(1);

    return NextResponse.json({
      ok: true,
      hasPassword: !!(existingUser?.passwordHash),
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "درخواست کد تأیید انجام نشد. لطفاً دوباره تلاش کنید." },
      { status: 503 },
    );
  }
}

export { hashOtp, verifyOtp };
