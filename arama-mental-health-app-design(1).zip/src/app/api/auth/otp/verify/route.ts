import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { and, desc, eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { loginAttempts, otpCodes, profiles } from "@/db/schema";

function verifyOtp(code: string, stored: string): boolean {
  if (!stored || !stored.includes(":")) return false;
  const [salt, key] = stored.split(":");
  const keyBuf = Buffer.from(key, "hex");
  const derivedKey = scryptSync(code, salt, 64);
  return keyBuf.length === derivedKey.length && timingSafeEqual(keyBuf, derivedKey);
}

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const buf = scryptSync(password, salt, 64);
  return `${salt}:${buf.toString("hex")}`;
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as { phone?: string; code?: string };
    const phone = body.phone?.trim();
    const code = body.code?.trim();

    if (!phone || !/^09\d{9}$/.test(phone)) {
      return NextResponse.json({ error: "شماره موبایل معتبر نیست." }, { status: 400 });
    }
    if (!code || !/^\d{5}$/.test(code)) {
      return NextResponse.json({ error: "کد تأیید باید ۵ رقم باشد." }, { status: 400 });
    }

    // ── Find latest unexpired, unverified OTP for this phone ──
    const [otpRecord] = await db
      .select()
      .from(otpCodes)
      .where(and(eq(otpCodes.phone, phone), eq(otpCodes.verified, false)))
      .orderBy(desc(otpCodes.createdAt))
      .limit(1);

    if (!otpRecord) {
      return NextResponse.json(
        { error: "کد تأییدی برای این شماره یافت نشد. لطفاً کد جدیدی درخواست کنید." },
        { status: 404 },
      );
    }

    // ── Check expiry ──
    if (new Date() > otpRecord.expiresAt) {
      return NextResponse.json(
        { error: "کد تأیید منقضی شده است. لطفاً کد جدیدی درخواست کنید." },
        { status: 410 },
      );
    }

    // ── Rate-limit verification: max 5 attempts per code ──
    if (otpRecord.attempts >= 5) {
      return NextResponse.json(
        { error: "تعداد تلاش‌های ناموفق بیش از حد مجاز است. لطفاً کد جدیدی درخواست کنید." },
        { status: 429 },
      );
    }

    // ── Increment attempt count ──
    await db
      .update(otpCodes)
      .set({ attempts: otpRecord.attempts + 1 })
      .where(eq(otpCodes.id, otpRecord.id));

    // ── Verify code ──
    if (!verifyOtp(code, otpRecord.codeHash)) {
      return NextResponse.json(
        { error: "کد تأیید اشتباه است. لطفاً دوباره تلاش کنید." },
        { status: 401 },
      );
    }

    // ── Mark OTP as verified (one-time use) ──
    await db.update(otpCodes).set({ verified: true }).where(eq(otpCodes.id, otpRecord.id));

    // ── Find or create user ──
    let [user] = await db.select().from(profiles).where(eq(profiles.phone, phone)).limit(1);

    const isFirstLogin = !user;

    if (!user) {
      const userId = `user-${crypto.randomUUID()}`;
      [user] = await db
        .insert(profiles)
        .values({ userId, phone, name: "" })
        .returning();
    }

    // ── Record successful login ──
    await db.insert(loginAttempts).values({ phone, success: true });

    // ── Issue session cookie ──
    const response = NextResponse.json({
      ok: true,
      isFirstLogin,
      hasPassword: !!user.passwordHash,
      profile: {
        userId: user.userId,
        name: user.name,
        phone: user.phone,
        avatarUrl: user.avatarUrl,
      },
    });

    response.cookies.set("arama-user", user.userId, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
    });

    return response;
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "تأیید کد انجام نشد. لطفاً دوباره تلاش کنید." },
      { status: 503 },
    );
  }
}
