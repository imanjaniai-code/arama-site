import { randomBytes, scryptSync, timingSafeEqual } from "node:crypto";
import { and, desc, eq, gt } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { loginAttempts, profiles } from "@/db/schema";

function verifyPassword(password: string, stored: string | null): boolean {
  if (!stored || !stored.includes(":")) return false;
  const [salt, key] = stored.split(":");
  const keyBuf = Buffer.from(key, "hex");
  const derivedKey = scryptSync(password, salt, 64);
  return keyBuf.length === derivedKey.length && timingSafeEqual(keyBuf, derivedKey);
}

export async function POST(request: NextRequest) {
  try {
    const body = (await request.json()) as { phone?: string; password?: string };
    const phone = body.phone?.trim();
    const password = body.password ?? "";

    if (!phone || !/^09\d{9}$/.test(phone)) {
      return NextResponse.json({ error: "شماره موبایل معتبر نیست." }, { status: 400 });
    }
    if (password.length < 8) {
      return NextResponse.json({ error: "رمز عبور باید دست‌کم ۸ نویسه باشد." }, { status: 400 });
    }

    // ── Account lockout: 5 failed attempts in 15 minutes ──
    const fifteenMinsAgo = new Date(Date.now() - 15 * 60 * 1000);
    const recentAttempts = await db
      .select()
      .from(loginAttempts)
      .where(and(eq(loginAttempts.phone, phone), gt(loginAttempts.attemptAt, fifteenMinsAgo)))
      .orderBy(desc(loginAttempts.attemptAt));

    let failedCount = 0;
    for (const attempt of recentAttempts) {
      if (attempt.success) break;
      failedCount++;
    }

    if (failedCount >= 5) {
      return NextResponse.json(
        { error: "به دلیل تلاش‌های ناموفق متعدد، حساب موقتاً مسدود شده است. لطفاً ۱۵ دقیقه دیگر تلاش کنید." },
        { status: 429 },
      );
    }

    const [user] = await db.select().from(profiles).where(eq(profiles.phone, phone)).limit(1);

    if (!user || !verifyPassword(password, user.passwordHash)) {
      await db.insert(loginAttempts).values({ phone, success: false });
      return NextResponse.json(
        { error: "شماره موبایل یا رمز عبور اشتباه است." },
        { status: 401 },
      );
    }

    await db.insert(loginAttempts).values({ phone, success: true });

    const response = NextResponse.json({
      ok: true,
      isFirstLogin: false,
      hasPassword: true,
      profile: { userId: user.userId, name: user.name, phone: user.phone, avatarUrl: user.avatarUrl },
    });

    response.cookies.set("arama-user", user.userId, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      path: "/",
    });

    return response;
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { error: "ورود انجام نشد. لطفاً دوباره تلاش کنید." },
      { status: 503 },
    );
  }
}
