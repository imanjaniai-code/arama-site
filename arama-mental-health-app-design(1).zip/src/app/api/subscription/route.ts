import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { plans, subscriptions } from "@/db/schema";
import { getSessionUserId, unauthorized } from "@/lib/session";

export async function GET() {
  try {
    const userId = await getSessionUserId();
    if (!userId) return unauthorized();

    const [row] = await db
      .select({ subscription: subscriptions, plan: plans })
      .from(subscriptions)
      .innerJoin(plans, eq(subscriptions.planId, plans.id))
      .where(eq(subscriptions.userId, userId))
      .limit(1);
    return NextResponse.json({ subscription: row ?? null });
  } catch {
    return NextResponse.json({ error: "اطلاعات اشتراک فعلاً در دسترس نیست." }, { status: 503 });
  }
}

export async function POST(request: NextRequest) {
  try {
    const userId = await getSessionUserId();
    if (!userId) return unauthorized();

    const { action, planId } = (await request.json()) as { action?: string; planId?: string };
    
    if (action === "cancel") {
      await db.update(subscriptions).set({ status: "canceled" }).where(eq(subscriptions.userId, userId));
      return NextResponse.json({ ok: true });
    }
    
    if (action === "upgrade" || action === "subscribe") {
      if (!planId) return NextResponse.json({ error: "طرح انتخاب نشده است." }, { status: 400 });
      const [plan] = await db.select().from(plans).where(eq(plans.id, planId)).limit(1);
      if (!plan) return NextResponse.json({ error: "طرح نامعتبر است." }, { status: 400 });
      
      const [existing] = await db.select().from(subscriptions).where(eq(subscriptions.userId, userId)).limit(1);
      if (existing) {
        await db.update(subscriptions).set({
          planId: plan.id,
          status: "active",
          amount: plan.price,
          renewsAt: new Date(Date.now() + 30 * 86400000)
        }).where(eq(subscriptions.userId, userId));
      } else {
        await db.insert(subscriptions).values({
          userId,
          planId: plan.id,
          status: "active",
          amount: plan.price,
          interval: "month",
          renewsAt: new Date(Date.now() + 30 * 86400000)
        });
      }
      return NextResponse.json({ ok: true });
    }
    
    return NextResponse.json({ error: "درخواست نامعتبر است." }, { status: 400 });
  } catch {
    return NextResponse.json({ error: "تغییر اشتراک انجام نشد." }, { status: 500 });
  }
}
