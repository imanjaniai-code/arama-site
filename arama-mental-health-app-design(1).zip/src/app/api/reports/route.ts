import { asc, eq } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { moodEntries, exerciseCompletions } from "@/db/schema";
import { getSessionUserId, unauthorized } from "@/lib/session";

export async function GET() {
  try {
    const userId = await getSessionUserId();
    if (!userId) return unauthorized();

    const rows = await db
      .select()
      .from(moodEntries)
      .where(eq(moodEntries.userId, userId))
      .orderBy(asc(moodEntries.checkedInAt));

    const exercises = await db
      .select({ id: exerciseCompletions.id })
      .from(exerciseCompletions)
      .where(eq(exerciseCompletions.userId, userId));

    const average = rows.length ? rows.reduce((sum, row) => sum + row.mood, 0) / rows.length : 0;
    const best = rows.length ? Math.max(...rows.map((row) => row.mood)) : 0;
    const latest = rows.at(-1);
    
    return NextResponse.json({
      report: {
        checkIns: rows.length,
        average: Number(average.toFixed(1)),
        best,
        latestLabel: latest?.label ?? null,
        trend: rows.length > 1 ? rows.at(-1)!.mood - rows[0].mood : 0,
        entries: rows.map((row) => ({ mood: row.mood, label: row.label, checkedInAt: row.checkedInAt.toISOString() })),
        completedExercises: exercises.length
      },
    });
  } catch {
    return NextResponse.json({ error: "گزارش هفتگی فعلاً آماده نیست." }, { status: 503 });
  }
}
