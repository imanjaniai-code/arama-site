import { randomBytes, scryptSync } from "node:crypto";
import { eq } from "drizzle-orm";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { profiles } from "@/db/schema";
import { getSessionUserId, unauthorized } from "@/lib/session";

function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const buf = scryptSync(password, salt, 64);
  return `${salt}:${buf.toString("hex")}`;
}

export async function GET() {
  try {
    const userId = await getSessionUserId();
    if (!userId) return unauthorized();

    const [profile] = await db.select({
      userId: profiles.userId,
      name: profiles.name,
      phone: profiles.phone,
      email: profiles.email,
      timezone: profiles.timezone,
      remindersEnabled: profiles.remindersEnabled,
      avatarUrl: profiles.avatarUrl
    }).from(profiles).where(eq(profiles.userId, userId)).limit(1);
    
    return NextResponse.json({ profile });
  } catch {
    return NextResponse.json({ error: "پروفایل فعلاً در دسترس نیست." }, { status: 503 });
  }
}

export async function PUT(request: NextRequest) {
  try {
    const userId = await getSessionUserId();
    if (!userId) return unauthorized();

    const body = (await request.json()) as { 
      name?: string; 
      timezone?: string; 
      remindersEnabled?: boolean;
      avatarUrl?: string;
      password?: string;
    };
    
    const name = body.name?.trim();
    if (!name || name.length < 2) return NextResponse.json({ error: "نام باید دست‌کم دو حرف باشد." }, { status: 400 });
    
    const updates: Partial<typeof profiles.$inferInsert> = {
      name,
      timezone: body.timezone || "Asia/Tehran",
      remindersEnabled: body.remindersEnabled ?? true,
      updatedAt: new Date()
    };
    
    if (body.avatarUrl !== undefined) {
      updates.avatarUrl = body.avatarUrl;
    }
    if (body.password) {
      if (body.password.length < 8) return NextResponse.json({ error: "رمز عبور جدید باید دست‌کم ۸ نویسه باشد." }, { status: 400 });
      updates.passwordHash = hashPassword(body.password);
    }

    const [profile] = await db
      .update(profiles)
      .set(updates)
      .where(eq(profiles.userId, userId))
      .returning({
        userId: profiles.userId,
        name: profiles.name,
        phone: profiles.phone,
        email: profiles.email,
        timezone: profiles.timezone,
        remindersEnabled: profiles.remindersEnabled,
        avatarUrl: profiles.avatarUrl
      });
      
    return NextResponse.json({ profile });
  } catch {
    return NextResponse.json({ error: "ذخیرهٔ تنظیمات انجام نشد." }, { status: 500 });
  }
}
