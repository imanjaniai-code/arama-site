import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { exerciseCompletions } from "@/db/schema";
import { getSessionUserId, unauthorized } from "@/lib/session";

export async function POST(request: NextRequest) {
  try {
    const userId = await getSessionUserId();
    if (!userId) return unauthorized();

    const body = (await request.json()) as { exerciseId?: string };
    if (!body.exerciseId) return NextResponse.json({ error: "شناسه تمرین لازم است." }, { status: 400 });

    await db.insert(exerciseCompletions).values({
      userId,
      exerciseId: body.exerciseId
    });
    
    return NextResponse.json({ ok: true }, { status: 201 });
  } catch {
    return NextResponse.json({ error: "ثبت تمرین انجام نشد." }, { status: 500 });
  }
}
