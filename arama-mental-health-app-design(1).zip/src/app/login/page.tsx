import type { Metadata } from "next";
import { AuthForm } from "@/components/auth-form";
import { AuthShell } from "@/components/auth-shell";

export const metadata: Metadata = { title: "ورود" };

export default function AuthPage() {
  return (
    <AuthShell
      title="خوش آمدی"
      subtitle="یک شماره موبایل کافیست؛ کد تأیید برایت می‌فرستیم و وارد فضای امنت می‌شوی."
      aside={
        <p className="mt-8 border-t border-line pt-6 text-center text-xs leading-6 text-white/60">
          با ورود، <a href="#" className="font-bold text-white/90 underline-offset-4 hover:underline">قوانین حریم خصوصی</a> آراما را می‌پذیری.
        </p>
      }
    >
      <AuthForm />
    </AuthShell>
  );
}
