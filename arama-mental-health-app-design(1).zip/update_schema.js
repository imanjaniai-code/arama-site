const fs = require('fs');

let schema = fs.readFileSync('src/db/schema.ts', 'utf8');

if (!schema.includes("export const exerciseCompletions")) {
  schema += `
export const exerciseCompletions = pgTable("exercise_completions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: text("user_id").notNull(),
  exerciseId: uuid("exercise_id")
    .notNull()
    .references(() => exercises.id, { onDelete: "cascade" }),
  completedAt: timestamp("completed_at", { withTimezone: true }).defaultNow().notNull(),
});

export const loginAttempts = pgTable("login_attempts", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: text("email").notNull(),
  attemptAt: timestamp("attempt_at", { withTimezone: true }).defaultNow().notNull(),
  success: boolean("success").notNull(),
});
`;
}

if (!schema.includes("avatarUrl")) {
  schema = schema.replace(
    'timezone: text("timezone").default("Asia/Tehran").notNull(),',
    'timezone: text("timezone").default("Asia/Tehran").notNull(),\n  avatarUrl: text("avatar_url"),'
  );
}

fs.writeFileSync('src/db/schema.ts', schema);
